﻿using System;

namespace riskdemo
{
    class Program
    {
        static void Main(string[] args)
        {
           
            game g = new game();
        }
    }
}
