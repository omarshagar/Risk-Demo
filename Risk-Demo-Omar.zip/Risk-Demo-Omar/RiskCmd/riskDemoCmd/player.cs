﻿using System;
using System.Collections.Generic;
using System.Text;

namespace riskdemo
{
    class player
    {
        public int notusedtroops;
        public int usedtroops;
        public int cards;
        public int id;
       // public  string name;
        public int contents;
        public int  countries;
        public player()
        {
            notusedtroops = 35;
            usedtroops = 35;
            cards = 0;
            countries = 0;
        }

    }
}
